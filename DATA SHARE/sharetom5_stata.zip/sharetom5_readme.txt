sharetom5 - editing missing values in SHARE data

version 1.0


Save sharetom5.ado and sharetom5.hlp in a location on your hard drive where Stata can find it,  
e.g. your personal ado-directory. If you are not sure about the location, type "adopath" in
Stata to get a list of the recognized ado folders.

'sharetom5' is an updated version of 'sharetom' and 'sharetom4', compatible with data of all waves as of release 3.0.0.
Please do not use 'sharetom' on SHARE wave 4 or wave 5 data. You may, on the other hand, use 'sharetom5' on previous
releases of wave 4 and 5, as well as release versions 2.2.0 or higher of wave 1 and 2.

contact:
Thorsten Kneip
Tim Birkenbach
info@share-project.org

Please report bugs!